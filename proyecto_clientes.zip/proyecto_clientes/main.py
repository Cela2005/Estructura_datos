# Importamos la clase Estudiante desde models.py.
# La usamos para crear y trabajar con estudiantes.
from models import Estudiante


# Importamos GestorJSON.
# Sirve para leer y guardar información en el archivo JSON.
from shared.json_manager import GestorJSON


# Importamos una función que revisa si el correo es válido.
from shared.herramientas import es_email_valido


# ============================================================
# ARCHIVO JSON
# ============================================================

# Creamos el gestor que trabajará con el archivo
# donde se guardan los estudiantes.
gestor = GestorJSON("data/estudiantes.json")


# ============================================================
# CAMPOS DEL ESTUDIANTE
# ============================================================

# Esta tupla contiene los datos principales
# que tiene un estudiante.
CAMPOS_ESTUDIANTE = (
    "nombre",
    "apellido",
    "email",
    "carnet"
)


# ============================================================
# CREAR ESTUDIANTE
# ============================================================

# Esta función sirve para crear un estudiante nuevo.
#
# "datos" contiene la información del estudiante.
def crear_estudiante(datos):

    # Obtenemos el nombre del diccionario.
    # strip() elimina espacios al inicio y al final.
    nombre = datos.get("nombre", "").strip()

    # Obtenemos el apellido.
    apellido = datos.get("apellido", "").strip()

    # Obtenemos el correo.
    email = datos.get("email", "").strip()

    # Obtenemos el carnet.
    carnet = datos.get("carnet", "").strip()


    # Revisamos que ningún campo esté vacío.
    #
    # Si falta algún dato, mostramos un mensaje
    # y terminamos la función.
    if not nombre or not apellido or not email or not carnet:
        return False, "Todos los campos son obligatorios."

    # Revisamos si el correo tiene un formato válido.
    if not es_email_valido(email):
        return False, "El email no es válido."

    # Leemos los estudiantes que ya están guardados.
    registros = gestor.leer()

    # Revisamos si el correo ya está registrado.
    for registro in registros:

        # lower() convierte el texto a minúsculas
        # para poder comparar mejor.
        if registro["email"].lower() == email.lower():

            # Si ya existe, no permitimos registrarlo.
            return False, "Ese email ya está registrado."

    # Revisamos si el carnet ya está registrado.
    for registro in registros:

        if registro["carnet"].lower() == carnet.lower():

            # Si ya existe, mostramos un mensaje.
            return False, "Ese carnet ya está registrado."

    # =======================================================
    # CREAR ID
    # ========================================================

    # Si ya existen estudiantes...
    if registros:

        # Buscamos el ID más grande y le sumamos 1.
        #
        # Ejemplo:
        # 1, 2, 3 -> el nuevo será 4.
        id_nuevo = max(
            registro["id"] for registro in registros
        ) + 1

    else:

        # Si no existen estudiantes,
        # el primer ID será 1.
        id_nuevo = 1


    # ========================================================
    # CREAR OBJETO
    # ========================================================

    # Creamos un nuevo objeto Estudiante.
    estudiante = Estudiante(
        id_nuevo,
        nombre,
        apellido,
        email,
        carnet
    )

    # Convertimos el estudiante a diccionario
    # y lo agregamos a la lista.
    registros.append(
        estudiante.a_diccionario()
    )

    # Guardamos la lista en el archivo JSON.
    if gestor.guardar(registros):

        # True significa que se guardó correctamente.
        return True, "Estudiante creado correctamente."

    # Si no se pudo guardar.
    return False, "No se pudo guardar el estudiante."

# ============================================================
# OBTENER TODOS
# ============================================================

# Esta función obtiene todos los estudiantes.
def obtener_todos():

    # Leemos los datos del archivo JSON.
    registros = gestor.leer()

    # Creamos una lista vacía.
    estudiantes = []

    # Recorremos todos los registros.
    for registro in registros:

        # Convertimos cada registro en un objeto Estudiante.
        estudiante = Estudiante.desde_diccionario(
            registro
        )

        # Agregamos el estudiante a la lista.
        estudiantes.append(estudiante)


    # Devolvemos la lista de estudiantes.
    return estudiantes

# ============================================================
# BUSCAR POR ID
# ============================================================

# Esta función busca un estudiante usando su ID.
def obtener_por_id(id_estudiante):

    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()


    # Recorremos la lista.
    for estudiante in estudiantes:

        # Comparamos el ID del estudiante
        # con el ID que estamos buscando.
        if estudiante.id == id_estudiante:

            # Si coincide, devolvemos el estudiante.
            return estudiante

    # Si no encontramos el estudiante,
    # devolvemos None.
    return None

# ===========================================================
# BUSCAR ESTUDIANTES
# ============================================================

# Esta función permite buscar por:
# nombre, apellido, email o carnet.
def buscar_estudiantes(termino):

    # Convertimos la búsqueda a minúsculas
    # y quitamos espacios.
    termino = termino.lower().strip()

    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()

    # Creamos una lista vacía para los resultados.
    encontrados = []

    # Recorremos todos los estudiantes.
    for estudiante in estudiantes:

        # Buscamos el término dentro del nombre.
        if termino in estudiante.nombre.lower():

            # Si coincide, lo agregamos.
            encontrados.append(estudiante)


        # Si no está en el nombre,
        # buscamos en el apellido.
        elif termino in estudiante.apellido.lower():

            encontrados.append(estudiante)


        # Si no está en el apellido,
        # buscamos en el email.
        elif termino in estudiante.email.lower():

            encontrados.append(estudiante)


        # Si no está en el email,
        # buscamos en el carnet.
        elif termino in estudiante.carnet.lower():

            encontrados.append(estudiante)


    # Devolvemos los estudiantes encontrados.
    return encontrados

# ============================================================
# ACTUALIZAR ESTUDIANTE
# ============================================================

# Esta función sirve para modificar
# los datos de un estudiante.
def actualizar_estudiante(id_estudiante, cambios):

    # Leemos los estudiantes guardados.
    registros = gestor.leer()


    # Recorremos todos los registros.
    for registro in registros:

        # Buscamos el estudiante por su ID.
        if registro["id"] == id_estudiante:


            # Si se recibió un nuevo nombre,
            # actualizamos el nombre.
            if "nombre" in cambios and cambios["nombre"]:
                registro["nombre"] = cambios["nombre"]


            # Si se recibió un nuevo apellido,
            # actualizamos el apellido.
            if "apellido" in cambios and cambios["apellido"]:
                registro["apellido"] = cambios["apellido"]


            # Si se recibió un nuevo email...
            if "email" in cambios and cambios["email"]:

                # Primero revisamos que sea válido.
                if not es_email_valido(cambios["email"]):
                    return False, "El email no es válido."

                # Guardamos el nuevo email.
                registro["email"] = cambios["email"]


            # Si se recibió un nuevo carnet,
            # actualizamos el carnet.
            if "carnet" in cambios and cambios["carnet"]:
                registro["carnet"] = cambios["carnet"]


            # Guardamos los cambios.
            if gestor.guardar(registros):
                return True, "Estudiante actualizado correctamente."


            # Si no se pudo guardar.
            return False, "No se pudo guardar los cambios."


    # Si no encontramos el ID.
    return False, "No existe ese estudiante."

# ============================================================
# ELIMINAR ESTUDIANTE
# ============================================================

# Esta función elimina un estudiante usando su ID.
def eliminar_estudiante(id_estudiante):

    # Leemos los registros.
    registros = gestor.leer()


    # Creamos una lista vacía.
    # Aquí guardaremos los estudiantes que NO eliminaremos.
    nuevos_registros = []


    # Esta variable nos indica si encontramos
    # al estudiante.
    encontrado = False


    # Recorremos todos los registros.
    for registro in registros:

        # Si encontramos el ID que queremos eliminar...
        if registro["id"] == id_estudiante:

            # Indicamos que sí lo encontramos.
            encontrado = True


        else:

            # Si no es el estudiante que queremos eliminar,
            # lo conservamos en la nueva lista.
            nuevos_registros.append(registro)


    # Si no encontramos el estudiante...
    if not encontrado:
        return False, "No existe ese estudiante."


    # Guardamos la nueva lista.
    #
    # El estudiante eliminado ya no está en la lista.
    if gestor.guardar(nuevos_registros):
        return True, "Estudiante eliminado correctamente."


    # Si no se pudo guardar.
    return False, "No se pudo eliminar el estudiante."

# ============================================================
# AGREGAR NOTA
# ============================================================

# Esta función agrega una nota a un estudiante.
def agregar_nota(id_estudiante, materia, nota):

    # Intentamos convertir la nota a número.
    try:

        # float permite usar números como 18.5.
        nota = float(nota)

    # Si no se puede convertir a número...
    except ValueError:

        # Mostramos un mensaje de error.
        return False, "La nota debe ser un número."


    # Revisamos que la nota esté entre 0 y 20.
    if nota < 0 or nota > 20:
        return False, "La nota debe estar entre 0 y 20."


    # Quitamos espacios de la materia.
    materia = materia.strip()


    # Revisamos que la materia no esté vacía.
    if not materia:
        return False, "Debe escribir una materia."


    # Buscamos al estudiante por su ID.
    estudiante = obtener_por_id(id_estudiante)


    # Si no existe el estudiante...
    if estudiante is None:
        return False, "No existe ese estudiante."


    # Agregamos la nota al estudiante.
    estudiante.agregar_nota(
        materia,
        nota
    )


    # Volvemos a leer los registros.
    registros = gestor.leer()


    # Recorremos la lista usando posiciones.
    for i in range(len(registros)):

        # Buscamos el estudiante por su ID.
        if registros[i]["id"] == id_estudiante:

            # Reemplazamos sus datos por los actualizados.
            registros[i] = estudiante.a_diccionario()


    # Guardamos los cambios.
    if gestor.guardar(registros):
        return True, "Nota agregada correctamente."


    # Si no se pudo guardar.
    return False, "No se pudo guardar la nota."

# ============================================================
# OBTENER PROMEDIO
# ============================================================

# Esta función obtiene el promedio del estudiante.
def obtener_promedio(id_estudiante):

    # Buscamos al estudiante.
    estudiante = obtener_por_id(id_estudiante)


    # Si no existe...
    if estudiante is None:
        return False, "No existe ese estudiante."


    # Llamamos al método que calcula el promedio.
    promedio = estudiante.obtener_promedio()


    # Devolvemos True y el promedio.
    return True, promedio

# ============================================================
# MATERIAS OFERTADAS
# ============================================================

# Esta función obtiene todas las materias
# sin repetirlas.
def materias_ofertadas():

    # Creamos un conjunto vacío.
    #
    # Un set no permite datos repetidos.
    materias = set()


    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()


    # Recorremos los estudiantes.
    for estudiante in estudiantes:

        # Agregamos las materias del estudiante
        # al conjunto general.
        materias.update(
            estudiante.materias
        )


    # Devolvemos las materias.
    return materias

# ============================================================
# MATERIAS EN COMÚN
# ============================================================

# Esta función busca las materias que tienen
# dos estudiantes en común.
def estudiantes_en_comun(id_a, id_b):

    # Buscamos al primer estudiante.
    estudiante_a = obtener_por_id(id_a)


    # Buscamos al segundo estudiante.
    estudiante_b = obtener_por_id(id_b)


    # Revisamos si existe el primer estudiante.
    if estudiante_a is None:
        return False, "No existe el primer estudiante."


    # Revisamos si existe el segundo estudiante.
    if estudiante_b is None:
        return False, "No existe el segundo estudiante."


    # Buscamos las materias que ambos tienen.
    #
    # El método materias_en_comun()
    # compara las materias de los dos estudiantes.
    materias = estudiante_a.materias_en_comun(
        estudiante_b
    )


    # Devolvemos True porque la búsqueda fue correcta
    # y también devolvemos las materias encontradas.
    return True, materias
