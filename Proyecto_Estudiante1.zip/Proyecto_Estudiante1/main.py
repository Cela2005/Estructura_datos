# Importamos funciones que sirven para mostrar títulos,
# mensajes de éxito, errores e información en pantalla.
from shared.herramientas import (
    imprimir_titulo,
    imprimir_exito,
    imprimir_error,
    imprimir_info,
)

# Importamos las funciones que realizan las operaciones
# principales del sistema de estudiantes.
from views import (
    crear_estudiante,       # Crea un estudiante
    obtener_todos,          # Obtiene todos los estudiantes
    obtener_por_id,         # Busca un estudiante por su ID
    buscar_estudiantes,     # Busca estudiantes por diferentes datos
    actualizar_estudiante,  # Modifica los datos de un estudiante
    eliminar_estudiante,    # Elimina un estudiante
    agregar_nota,           # Agrega una nota a un estudiante
    obtener_promedio,       # Calcula u obtiene el promedio
    materias_ofertadas,     # Muestra las materias disponibles
    estudiantes_en_comun,   # Busca materias en común entre dos estudiantes
)


# ===================== AYUDAS =====================

# Esta función pide al usuario el ID de un estudiante.
def pedir_id():
    """Solicita un ID entero."""

    # try permite intentar ejecutar un código
    # que podría producir un error.
    try:
        # input() recibe el ID.
        # strip() elimina espacios al inicio y al final.
        # int() convierte el texto recibido en número entero.
        return int(input("ID del estudiante: ").strip())

    # Si el usuario escribe algo que no es un número,
    # se produce un ValueError.
    except ValueError:
        # En lugar de detener el programa, devuelve None.
        return None


# Esta función muestra los datos principales
# de un estudiante.
def mostrar_estudiante(estudiante):

    # Muestra el ID del estudiante.
    print(f"ID: {estudiante.id}")

    # Llama al método que obtiene nombre y apellido juntos.
    print(f"Nombre: {estudiante.obtener_nombre_completo()}")

    # Muestra el correo electrónico.
    print(f"Email: {estudiante.email}")

    # Muestra el carnet.
    print(f"Carnet: {estudiante.carnet}")

    # Muestra las materias del estudiante.
    # sorted() ordena las materias alfabéticamente.
    # join() las une usando una coma.
    # Si no tiene materias, muestra "Ninguna".
    print(
        f"Materias: "
        f"{', '.join(sorted(estudiante.materias)) if estudiante.materias else 'Ninguna'}"
    )

    # Muestra el promedio del estudiante.
    print(f"Promedio: {estudiante.obtener_promedio()}")

    # Imprime una línea para separar un estudiante de otro.
    print("-" * 50)


# ===================== CREATE =====================

# Esta función se encarga de crear un estudiante.
def menu_crear():

    # Muestra el título de la sección.
    imprimir_titulo("CREAR ESTUDIANTE")

    # Creamos un diccionario llamado datos.
    # Aquí guardamos la información que escribe el usuario.
    datos = {
        "nombre": input("Nombre: ").strip(),
        "apellido": input("Apellido: ").strip(),
        "email": input("Email: ").strip(),
        "carnet": input("Carnet: ").strip(),
    }

    # Enviamos los datos a la función crear_estudiante().
    # Esta función devuelve dos valores:
    # exito = True o False
    # mensaje = explicación de lo ocurrido.
    exito, mensaje = crear_estudiante(datos)

    # Si la operación fue exitosa...
    if exito:
        # Mostramos un mensaje de éxito.
        imprimir_exito(mensaje)

    # Si ocurrió algún problema...
    else:
        # Mostramos el mensaje de error.
        imprimir_error(mensaje)


# ===================== READ =====================

# Esta función muestra todos los estudiantes.
def menu_listar():

    # Muestra el título.
    imprimir_titulo("LISTA DE ESTUDIANTES")

    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()

    # Si la lista está vacía...
    if not estudiantes:
        # Avisamos que no existen estudiantes.
        imprimir_info("No hay estudiantes registrados.")

        # return termina esta función.
        return

    # Recorremos cada estudiante de la lista.
    for estudiante in estudiantes:

        # Mostramos sus datos.
        mostrar_estudiante(estudiante)


# ===================== SEARCH =====================

# Esta función permite buscar un estudiante.
def menu_buscar():

    # Muestra el título.
    imprimir_titulo("BUSCAR ESTUDIANTE")

    # Pedimos al usuario el dato que quiere buscar.
    termino = input(
        "Ingrese nombre, apellido, email o carnet: "
    ).strip()

    # Buscamos estudiantes utilizando el término escrito.
    encontrados = buscar_estudiantes(termino)

    # Si no encontramos estudiantes...
    if not encontrados:

        # Mostramos un mensaje.
        imprimir_info("No se encontraron estudiantes.")

        # Terminamos la función.
        return

    # Recorremos los estudiantes encontrados.
    for estudiante in encontrados:

        # Mostramos la información de cada uno.
        mostrar_estudiante(estudiante)


# ===================== UPDATE =====================

# Esta función permite modificar los datos
# de un estudiante.
def menu_actualizar():

    # Muestra el título.
    imprimir_titulo("ACTUALIZAR ESTUDIANTE")

    # Pedimos el ID del estudiante.
    id_estudiante = pedir_id()

    # Si el ID no es válido...
    if id_estudiante is None:

        # Mostramos un error.
        imprimir_error("El ID debe ser un número entero.")

        # Terminamos la función.
        return

    # Buscamos al estudiante utilizando su ID.
    estudiante = obtener_por_id(id_estudiante)

    # Si no existe...
    if estudiante is None:

        # Mostramos un mensaje de error.
        imprimir_error(
            f"No existe un estudiante con ID {id_estudiante}."
        )

        return

    # Indicamos al usuario que puede dejar campos vacíos.
    print("Deje vacío un campo si no desea modificarlo.")

    # Creamos un diccionario vacío.
    # Aquí guardaremos solamente los datos que se quieren cambiar.
    cambios = {}

    # Pedimos el nuevo nombre.
    nombre = input(
        f"Nombre [{estudiante.nombre}]: "
    ).strip()

    # Pedimos el nuevo apellido.
    apellido = input(
        f"Apellido [{estudiante.apellido}]: "
    ).strip()

    # Pedimos el nuevo email.
    email = input(
        f"Email [{estudiante.email}]: "
    ).strip()

    # Pedimos el nuevo carnet.
    carnet = input(
        f"Carnet [{estudiante.carnet}]: "
    ).strip()

    # Si el usuario escribió un nombre,
    # lo agregamos al diccionario de cambios.
    if nombre:
        cambios["nombre"] = nombre

    # Si escribió un apellido, lo agregamos.
    if apellido:
        cambios["apellido"] = apellido

    # Si escribió un email, lo agregamos.
    if email:
        cambios["email"] = email

    # Si escribió un carnet, lo agregamos.
    if carnet:
        cambios["carnet"] = carnet

    # Enviamos el ID y los cambios
    # a la función que actualiza al estudiante.
    exito, mensaje = actualizar_estudiante(
        id_estudiante,
        cambios
    )

    # Si se actualizó correctamente...
    if exito:
        imprimir_exito(mensaje)

    # Si hubo un error...
    else:
        imprimir_error(mensaje)


# ===================== DELETE =====================

# Esta función elimina un estudiante.
def menu_eliminar():

    # Muestra el título.
    imprimir_titulo("ELIMINAR ESTUDIANTE")

    # Pedimos el ID.
    id_estudiante = pedir_id()

    # Verificamos si el ID es válido.
    if id_estudiante is None:
        imprimir_error("El ID debe ser un número entero.")
        return

    # Buscamos el estudiante.
    estudiante = obtener_por_id(id_estudiante)

    # Si no existe...
    if estudiante is None:
        imprimir_error(
            f"No existe un estudiante con ID {id_estudiante}."
        )
        return

    # Dejamos una línea en blanco.
    print()

    # Mostramos los datos antes de eliminar.
    mostrar_estudiante(estudiante)

    # Preguntamos al usuario si realmente quiere eliminarlo.
    confirmar = input(
        "¿Está seguro de eliminarlo? (si/no): "
    ).strip().lower()

    # Si la respuesta no es una de las respuestas aceptadas...
    if confirmar not in ("si", "sí", "s", "yes", "y"):

        # Cancelamos la operación.
        imprimir_info("Operación cancelada.")

        return

    # Eliminamos al estudiante mediante su ID.
    exito, mensaje = eliminar_estudiante(id_estudiante)

    # Si se eliminó correctamente...
    if exito:
        imprimir_exito(mensaje)

    # Si ocurrió un error...
    else:
        imprimir_error(mensaje)


# ===================== NOTAS =====================

# Esta función permite agregar una nota.
def menu_agregar_nota():

    # Muestra el título.
    imprimir_titulo("AGREGAR NOTA")

    # Pedimos el ID del estudiante.
    id_estudiante = pedir_id()

    # Comprobamos que el ID sea válido.
    if id_estudiante is None:
        imprimir_error("El ID debe ser un número entero.")
        return

    # Buscamos el estudiante.
    estudiante = obtener_por_id(id_estudiante)

    # Si no existe...
    if estudiante is None:
        imprimir_error(
            f"No existe un estudiante con ID {id_estudiante}."
        )
        return

    # Pedimos el nombre de la materia.
    materia = input("Materia: ").strip()

    # Pedimos la nota.
    nota = input("Nota (0-20): ").strip()

    # Enviamos el ID, materia y nota
    # a la función que agrega la nota.
    exito, mensaje = agregar_nota(
        id_estudiante,
        materia,
        nota
    )

    # Mostramos el resultado.
    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)


# ===================== PROMEDIO =====================

# Esta función permite consultar el promedio.
def menu_promedio():

    # Muestra el título.
    imprimir_titulo("VER PROMEDIO")

    # Pedimos el ID.
    id_estudiante = pedir_id()

    # Comprobamos si el ID es válido.
    if id_estudiante is None:
        imprimir_error("El ID debe ser un número entero.")
        return

    # Obtenemos el promedio del estudiante.
    resultado = obtener_promedio(id_estudiante)

    # resultado[0] indica si la operación fue exitosa.
    if resultado[0]:

        # resultado[1] contiene el promedio o el mensaje.
        imprimir_info(
            f"Promedio: {resultado[1]}"
        )

    # Si ocurrió un error...
    else:
        imprimir_error(resultado[1])


# ===================== MATERIAS OFERTADAS =====================

# Esta función muestra todas las materias disponibles.
def menu_materias():

    # Muestra el título.
    imprimir_titulo("MATERIAS OFERTADAS")

    # Obtenemos las materias.
    materias = materias_ofertadas()

    # Si no hay materias...
    if not materias:
        imprimir_info("Todavía no hay materias registradas.")
        return

    # Mostramos un título.
    print("Materias:")

    # Recorremos las materias.
    # sorted() las ordena alfabéticamente.
    for materia in sorted(materias):

        # Imprimimos cada materia.
        print(f"- {materia}")


# ===================== MATERIAS EN COMÚN =====================

# Esta función busca las materias que tienen
# en común dos estudiantes.
def menu_materias_comun():

    # Muestra el título.
    imprimir_titulo("MATERIAS EN COMÚN")

    # Pedimos el primer estudiante.
    print("Primer estudiante")

    # Guardamos su ID.
    id_a = pedir_id()

    # Verificamos que el ID sea correcto.
    if id_a is None:
        imprimir_error("El primer ID no es válido.")
        return

    # Pedimos el segundo estudiante.
    print("Segundo estudiante")

    # Guardamos su ID.
    id_b = pedir_id()

    # Verificamos que sea válido.
    if id_b is None:
        imprimir_error("El segundo ID no es válido.")
        return

    # Comparamos las materias de los dos estudiantes.
    exito, resultado = estudiantes_en_comun(
        id_a,
        id_b
    )

    # Si la operación tuvo un error...
    if not exito:
        imprimir_error(resultado)
        return

    # Si existen materias en común...
    if resultado:

        # Mostramos el mensaje.
        imprimir_info("Materias en común:")

        # Recorremos las materias.
        for materia in sorted(resultado):

            # Mostramos cada materia.
            print(f"- {materia}")

    # Si no tienen materias en común...
    else:
        imprimir_info(
            "Los estudiantes no tienen materias en común."
        )


# ===================== MENÚ PRINCIPAL =====================

# Esta función muestra las opciones principales
# del programa.
def mostrar_menu():

    # Imprimimos una línea de separación.
    print()

    print("=" * 60)

    # Nombre del sistema.
    print("              SISTEMA DE ESTUDIANTES")

    print("=" * 60)

    # Opciones disponibles.
    print("1. Crear estudiante")
    print("2. Listar estudiantes")
    print("3. Buscar estudiante")
    print("4. Actualizar estudiante")
    print("5. Eliminar estudiante")
    print("6. Agregar nota")
    print("7. Ver promedio")
    print("8. Ver materias ofertadas")
    print("9. Ver materias en común")
    print("0. Salir")

    print("=" * 60)


# Esta es la función principal del programa.
def main():

    # while True crea un ciclo que se repite
    # hasta que encontremos un break.
    while True:

        # Mostramos el menú.
        mostrar_menu()

        # Pedimos al usuario que seleccione una opción.
        opcion = input("Seleccione una opción: ").strip()

        # Si selecciona 1, crear estudiante.
        if opcion == "1":
            menu_crear()

        # Si selecciona 2, listar estudiantes.
        elif opcion == "2":
            menu_listar()

        # Si selecciona 3, buscar estudiante.
        elif opcion == "3":
            menu_buscar()

        # Si selecciona 4, actualizar estudiante.
        elif opcion == "4":
            menu_actualizar()

        # Si selecciona 5, eliminar estudiante.
        elif opcion == "5":
            menu_eliminar()

        # Si selecciona 6, agregar nota.
        elif opcion == "6":
            menu_agregar_nota()

        # Si selecciona 7, consultar promedio.
        elif opcion == "7":
            menu_promedio()

        # Si selecciona 8, mostrar materias.
        elif opcion == "8":
            menu_materias()

        # Si selecciona 9, buscar materias en común.
        elif opcion == "9":
            menu_materias_comun()

        # Si selecciona 0, termina el programa.
        elif opcion == "0":

            # Mostramos mensaje de salida.
            imprimir_info("Programa finalizado.")

            # break rompe el while True.
            break

        # Si escribe otra opción...
        else:

            # Mostramos un error.
            imprimir_error("Opción no válida.")

        # Pausa el programa hasta que el usuario presione ENTER.
        input("\nPresione ENTER para continuar...")


# Esta condición comprueba que este archivo
# se esté ejecutando directamente.
#
# Si es así, llama a la función main()
# y comienza el programa.
if __name__ == "__main__":
    main()

