
# Creamos una clase llamada Estudiante.
# La clase representa a un estudiante dentro del sistema.
class Estudiante:

    # Este texto explica brevemente para qué sirve la clase.
    """MODELO: representa a un estudiante. Usa las cuatro colecciones."""

    # __init__ es el constructor.
    # Se ejecuta automáticamente cuando creamos un objeto Estudiante.
    def __init__(
        self,
        id_estudiante,
        nombre,
        apellido,
        email,
        carnet,
        notas=None,
        materias=None
    ):

        # Guardamos el ID del estudiante.
        self.id = id_estudiante

        # Guardamos el nombre.
        self.nombre = nombre

        # Guardamos el apellido.
        self.apellido = apellido

        # Guardamos el correo electrónico.
        self.email = email

        # Guardamos el carnet.
        # Ejemplo: EST2026001
        self.carnet = carnet

        # DICCIONARIO DE LISTAS.
        #
        # Ejemplo:
        # {
        #     "Matemática": [18, 19],
        #     "Inglés": [17]
        # }
        #
        # Si notas tiene información, la guardamos.
        # Si viene vacía o es None, usamos un diccionario vacío.
        self.notas = notas if notas else {}

        # CONJUNTO (set).
        #
        # Guarda las materias en las que está inscrito.
        # Un conjunto no permite materias repetidas.
        #
        # Si existen materias, las convertimos en conjunto.
        # Si no existen, creamos un conjunto vacío.
        self.materias = set(materias) if materias else set()


    # Esta función obtiene el nombre completo.
    def obtener_nombre_completo(self):

        # Une nombre y apellido.
        # Ejemplo: "Tamya Cela"
        return f"{self.nombre} {self.apellido}"


    # Esta función sirve para inscribir al estudiante
    # en una materia.
    def inscribir_materia(self, materia):

        # add() agrega la materia al conjunto.
        #
        # Como es un set, si la materia ya existe,
        # NO se vuelve a repetir.
        self.materias.add(materia)


    # Esta función agrega una nota a una materia.
    def agregar_nota(self, materia, nota):

        # Primero inscribimos al estudiante en esa materia.
        self.inscribir_materia(materia)

        # setdefault() revisa si la materia ya existe
        # dentro del diccionario de notas.
        #
        # Si no existe, crea una lista vacía.
        #
        # Después append() agrega la nueva nota.
        #
        # Ejemplo:
        # "Matemática": [18]
        # Luego agregamos 19:
        # "Matemática": [18, 19]
        self.notas.setdefault(materia, []).append(nota)


    # Esta función calcula el promedio general
    # de todas las notas del estudiante.
    def obtener_promedio(self):

        # Creamos una lista vacía.
        # Aquí vamos a guardar todas las notas.
        todas = []

        # Recorremos los valores del diccionario.
        #
        # Por ejemplo:
        # Matemática -> [18, 19]
        # Inglés -> [17]
        for lista_notas in self.notas.values():

            # extend() agrega todos los elementos
            # de la lista de notas a "todas".
            #
            # Resultado:
            # todas = [18, 19, 17]
            todas.extend(lista_notas)

        # Si no existen notas...
        if not todas:

            # Devolvemos 0 como promedio.
            return 0

        # Calculamos el promedio.
        #
        # sum(todas) = suma de todas las notas
        # len(todas) = cantidad de notas
        #
        # round(..., 2) deja solamente 2 decimales.
        return round(sum(todas) / len(todas), 2)


    # Esta función busca las materias que tienen
    # en común dos estudiantes.
    def materias_en_comun(self, otro_estudiante):

        # El símbolo & representa la INTERSECCIÓN
        # entre dos conjuntos.
        #
        # Ejemplo:
        # Estudiante A = {"Matemática", "Inglés", "Python"}
        # Estudiante B = {"Inglés", "Python", "Base de Datos"}
        #
        # Resultado:
        # {"Inglés", "Python"}
        return self.materias & otro_estudiante.materias


    # Esta función convierte el objeto Estudiante
    # en un diccionario.
    #
    # Esto es útil para guardar los datos en un archivo JSON.
    def a_diccionario(self):

        # Creamos y devolvemos un diccionario.
        return {

            # Guardamos el ID.
            "id": self.id,

            # Guardamos el nombre.
            "nombre": self.nombre,

            # Guardamos el apellido.
            "apellido": self.apellido,

            # Guardamos el email.
            "email": self.email,

            # Guardamos el carnet.
            "carnet": self.carnet,

            # Guardamos las notas.
            "notas": self.notas,

            # JSON no puede guardar directamente un set.
            #
            # Por eso convertimos las materias
            # en una lista y además la ordenamos.
            "materias": sorted(self.materias),
        }


    # @classmethod permite crear un objeto Estudiante
    # utilizando los datos de un diccionario.
    #
    # Es útil cuando recuperamos información desde JSON.
    @classmethod
    def desde_diccionario(cls, datos):

        # Creamos y devolvemos un nuevo objeto Estudiante.
        return cls(

            # Obtenemos el ID del diccionario.
            datos["id"],

            # Obtenemos el nombre.
            datos["nombre"],

            # Obtenemos el apellido.
            datos["apellido"],

            # Obtenemos el email.
            datos["email"],

            # Obtenemos el carnet.
            datos["carnet"],

            # Obtenemos las notas.
            #
            # get() permite utilizar {} si no existe
            # la clave "notas".
            notas=datos.get("notas", {}),

            # Obtenemos las materias.
            #
            # JSON las guarda como lista,
            # pero aquí las convertimos nuevamente en set.
            materias=set(datos.get("materias", [])),
        )


    # __str__ define cómo se mostrará el objeto
    # cuando lo imprimamos con print().
    def __str__(self):

        # Devuelve una cadena con:
        # carnet + nombre completo + promedio.
        #
        # Ejemplo:
        # [EST2026001] Tamya Cela - Promedio: 18.0
        return (
            f"[{self.carnet}] "
            f"{self.obtener_nombre_completo()} - "
            f"Promedio: {self.obtener_promedio()}"
        )
