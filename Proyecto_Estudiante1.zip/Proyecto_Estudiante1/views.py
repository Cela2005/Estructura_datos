# Importamos la clase Estudiante desde models.py.
# Esta clase representa a cada estudiante.
from models import Estudiante

# Importamos GestorJSON.
# Esta clase permite leer y guardar información en un archivo JSON.
from shared.json_manager import GestorJSON

# Importamos una función que verifica si un email
# tiene un formato válido.
from shared.herramientas import es_email_valido


# Creamos un objeto GestorJSON.
# Le indicamos que los estudiantes se guardarán
# en el archivo data/estudiantes.json.
gestor = GestorJSON("data/estudiantes.json")


# TUPLA.
# Contiene los nombres de los campos que tiene un estudiante.
#
# Una tupla es una colección de datos que no se puede modificar.
CAMPOS_ESTUDIANTE = (
    "nombre",
    "apellido",
    "email",
    "carnet"
)


# ===================== CREAR =====================

# Esta función crea un nuevo estudiante.
def crear_estudiante(datos):

    # Este comentario/documentación explica qué hace la función.
    """Crea un nuevo estudiante."""

    # Obtenemos el nombre desde el diccionario datos.
    # get() busca la clave "nombre".
    # Si no existe, utiliza "".
    # strip() elimina espacios al principio y al final.
    nombre = datos.get("nombre", "").strip()

    # Obtenemos el apellido.
    apellido = datos.get("apellido", "").strip()

    # Obtenemos el email.
    email = datos.get("email", "").strip()

    # Obtenemos el carnet.
    carnet = datos.get("carnet", "").strip()


    # Comprobamos que ningún campo esté vacío.
    if not nombre or not apellido or not email or not carnet:

        # False significa que la operación no fue exitosa.
        # El segundo valor es el mensaje que se mostrará.
        return False, "Todos los campos son obligatorios."


    # Comprobamos que el email tenga un formato correcto.
    if not es_email_valido(email):

        # Si no es válido, terminamos la función.
        return False, "El email no es válido."


    # Leemos los estudiantes que ya están guardados
    # en el archivo JSON.
    registros = gestor.leer()


    # Recorremos los estudiantes existentes.
    for registro in registros:

        # Comparamos el email guardado con el nuevo email.
        # lower() permite comparar sin importar mayúsculas/minúsculas.
        if registro["email"].lower() == email.lower():

            # No permitimos emails repetidos.
            return False, "Ese email ya está registrado."


    # Recorremos nuevamente los registros
    # para comprobar si el carnet ya existe.
    for registro in registros:

        # Comparamos los carnets.
        if registro["carnet"].lower() == carnet.lower():

            # No permitimos carnets repetidos.
            return False, "Ese carnet ya está registrado."


    # Creamos un nuevo ID.
    #
    # Si ya existen estudiantes:
    # buscamos el ID más grande y le sumamos 1.
    if registros:
        id_nuevo = max(
            registro["id"] for registro in registros
        ) + 1

    # Si no existe ningún estudiante...
    else:

        # El primer ID será 1.
        id_nuevo = 1


    # Creamos un objeto de la clase Estudiante.
    estudiante = Estudiante(
        id_nuevo,
        nombre,
        apellido,
        email,
        carnet
    )


    # Convertimos el objeto Estudiante
    # en un diccionario para poder guardarlo en JSON.
    #
    # append() agrega el nuevo estudiante a la lista.
    registros.append(
        estudiante.a_diccionario()
    )


    # Guardamos todos los registros en el archivo JSON.
    if gestor.guardar(registros):

        # True significa que se guardó correctamente.
        return True, "Estudiante creado correctamente."


    # Si no se pudo guardar...
    return False, "No se pudo guardar el estudiante."


# ===================== LEER =====================

# Esta función obtiene todos los estudiantes.
def obtener_todos():

    """Devuelve todos los estudiantes."""

    # Leemos los registros del archivo JSON.
    registros = gestor.leer()

    # Creamos una lista vacía.
    estudiantes = []


    # Recorremos cada registro.
    for registro in registros:

        # Convertimos el diccionario nuevamente
        # en un objeto de tipo Estudiante.
        estudiante = Estudiante.desde_diccionario(
            registro
        )

        # Agregamos el objeto a la lista.
        estudiantes.append(estudiante)


    # Devolvemos la lista de estudiantes.
    return estudiantes


# Esta función busca un estudiante por su ID.
def obtener_por_id(id_estudiante):

    """Busca un estudiante por su ID."""

    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()


    # Recorremos la lista.
    for estudiante in estudiantes:

        # Comparamos el ID del estudiante
        # con el ID que buscamos.
        if estudiante.id == id_estudiante:

            # Si coincide, devolvemos ese estudiante.
            return estudiante


    # Si no encontramos nada,
    # devolvemos None.
    return None


# ===================== BUSCAR =====================

# Esta función permite buscar estudiantes
# por nombre, apellido, email o carnet.
def buscar_estudiantes(termino):

    """Busca por nombre, apellido, email o carnet."""

    # Convertimos el término a minúsculas
    # y eliminamos espacios.
    termino = termino.lower().strip()


    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()

    # Creamos una lista vacía para los resultados.
    encontrados = []


    # Recorremos cada estudiante.
    for estudiante in estudiantes:

        # Buscamos el término dentro del nombre.
        if termino in estudiante.nombre.lower():

            # Si coincide, agregamos el estudiante.
            encontrados.append(estudiante)


        # Si no coincidió con el nombre,
        # buscamos en el apellido.
        elif termino in estudiante.apellido.lower():

            encontrados.append(estudiante)


        # Si tampoco coincidió con el apellido,
        # buscamos en el email.
        elif termino in estudiante.email.lower():

            encontrados.append(estudiante)


        # Finalmente buscamos en el carnet.
        elif termino in estudiante.carnet.lower():

            encontrados.append(estudiante)


    # Devolvemos los estudiantes encontrados.
    return encontrados


# ===================== ACTUALIZAR =====================

# Esta función modifica los datos de un estudiante.
def actualizar_estudiante(id_estudiante, cambios):

    """Actualiza los datos de un estudiante."""

    # Leemos los registros del JSON.
    registros = gestor.leer()


    # Recorremos cada registro.
    for registro in registros:

        # Buscamos el estudiante por su ID.
        if registro["id"] == id_estudiante:


            # Si se recibió un nuevo nombre...
            if "nombre" in cambios and cambios["nombre"]:

                # Actualizamos el nombre.
                registro["nombre"] = cambios["nombre"]


            # Si se recibió un nuevo apellido...
            if "apellido" in cambios and cambios["apellido"]:

                # Actualizamos el apellido.
                registro["apellido"] = cambios["apellido"]


            # Si se recibió un nuevo email...
            if "email" in cambios and cambios["email"]:

                # Primero verificamos que sea válido.
                if not es_email_valido(cambios["email"]):

                    return False, "El email no es válido."

                # Guardamos el nuevo email.
                registro["email"] = cambios["email"]


            # Si se recibió un nuevo carnet...
            if "carnet" in cambios and cambios["carnet"]:

                # Actualizamos el carnet.
                registro["carnet"] = cambios["carnet"]


            # Guardamos los cambios en JSON.
            if gestor.guardar(registros):

                return True, "Estudiante actualizado correctamente."


            # Si no se pudo guardar...
            return False, "No se pudo guardar los cambios."


    # Si no encontramos el ID...
    return False, "No existe ese estudiante."


# ===================== ELIMINAR =====================

# Esta función elimina un estudiante.
def eliminar_estudiante(id_estudiante):

    """Elimina un estudiante."""

    # Leemos todos los registros.
    registros = gestor.leer()


    # Creamos una nueva lista.
    # Aquí colocaremos los estudiantes que NO vamos a eliminar.
    nuevos_registros = []


    # Esta variable nos indica si encontramos al estudiante.
    encontrado = False


    # Recorremos todos los registros.
    for registro in registros:

        # Si encontramos el ID que queremos eliminar...
        if registro["id"] == id_estudiante:

            # Indicamos que sí lo encontramos.
            encontrado = True


        # Si el ID no coincide...
        else:

            # Conservamos ese estudiante.
            nuevos_registros.append(registro)


    # Si nunca encontramos el estudiante...
    if not encontrado:

        return False, "No existe ese estudiante."


    # Guardamos la nueva lista sin el estudiante eliminado.
    if gestor.guardar(nuevos_registros):

        return True, "Estudiante eliminado correctamente."


    # Si ocurrió un error al guardar...
    return False, "No se pudo eliminar el estudiante."


# ===================== AGREGAR NOTA =====================

# Esta función agrega una nota a un estudiante.
def agregar_nota(id_estudiante, materia, nota):

    """Agrega una nota a un estudiante."""

    # Intentamos convertir la nota a número decimal.
    try:
        nota = float(nota)

    # Si el usuario escribe algo que no es número...
    except ValueError:

        return False, "La nota debe ser un número."


    # Comprobamos que la nota esté entre 0 y 20.
    if nota < 0 or nota > 20:

        return False, "La nota debe estar entre 0 y 20."


    # Eliminamos espacios de la materia.
    materia = materia.strip()


    # Comprobamos que haya escrito una materia.
    if not materia:

        return False, "Debe escribir una materia."


    # Buscamos al estudiante por su ID.
    estudiante = obtener_por_id(id_estudiante)


    # Si no existe...
    if estudiante is None:

        return False, "No existe ese estudiante."


    # Agregamos la nota al objeto estudiante.
    estudiante.agregar_nota(
        materia,
        nota
    )


    # Volvemos a leer los registros guardados.
    registros = gestor.leer()


    # Recorremos la lista utilizando índices.
    for i in range(len(registros)):

        # Buscamos el registro correspondiente
        # al estudiante.
        if registros[i]["id"] == id_estudiante:

            # Reemplazamos el registro anterior
            # por los datos actualizados.
            registros[i] = estudiante.a_diccionario()


    # Guardamos los cambios.
    if gestor.guardar(registros):

        return True, "Nota agregada correctamente."


    return False, "No se pudo guardar la nota."


# ===================== PROMEDIO =====================

# Esta función obtiene el promedio de un estudiante.
def obtener_promedio(id_estudiante):

    """Obtiene el promedio de un estudiante."""

    # Buscamos el estudiante.
    estudiante = obtener_por_id(id_estudiante)


    # Si no existe...
    if estudiante is None:

        return False, "No existe ese estudiante."


    # Utilizamos el método obtener_promedio()
    # de la clase Estudiante.
    promedio = estudiante.obtener_promedio()


    # Devolvemos True y el promedio.
    return True, promedio


# ===================== MATERIAS =====================

# Esta función obtiene todas las materias
# que tienen los estudiantes.
def materias_ofertadas():

    """Devuelve todas las materias sin repetir."""

    # Creamos un conjunto vacío.
    #
    # Los conjuntos no permiten elementos repetidos.
    materias = set()


    # Obtenemos todos los estudiantes.
    estudiantes = obtener_todos()


    # Recorremos cada estudiante.
    for estudiante in estudiantes:

        # update() agrega todas las materias
        # del estudiante al conjunto.
        materias.update(
            estudiante.materias
        )


    # Devolvemos el conjunto de materias.
    return materias


# ===================== MATERIAS EN COMÚN =====================

# Esta función busca las materias que comparten
# dos estudiantes.
def estudiantes_en_comun(id_a, id_b):

    """Busca las materias que tienen dos estudiantes."""


    # Buscamos al primer estudiante.
    estudiante_a = obtener_por_id(id_a)


    # Buscamos al segundo estudiante.
    estudiante_b = obtener_por_id(id_b)


    # Comprobamos si existe el primer estudiante.
    if estudiante_a is None:

        return False, "No existe el primer estudiante."


    # Comprobamos si existe el segundo estudiante.
    if estudiante_b is None:

        return False, "No existe el segundo estudiante."


    # Comparamos los conjuntos de materias.
    #
    # La función materias_en_comun()
    # utiliza la intersección (&).
    materias = estudiante_a.materias_en_comun(
        estudiante_b
    )


    # Devolvemos True y las materias en común.
    return True, materias
