# Ejercicio 1 · Quitar duplicados conservando el orden
# Dada ciudades = ["Quito","Guayaquil","Quito","Cuenca","Guayaquil"], 
# obtén una lista sin repetidos respetando el orden de aparición (un set solo no alcanza).

# ciudades = ['Quito','Guayaquil','Quito','Cuenca','Guayaquil']
# resultado = []

# for ciudad in ciudades:
#     if ciudad not in resultado:
#         resultado.append(ciudad)
# print(resultado)



# Ejercicio 2 ·
# Contar con un diccionario
# Con la misma lista, arma un diccionario {"Quito": 2, "Guayaquil": 2, "Cuenca": 1}.

ciudades = ['Quito', 'Guayaquil', 'Quito', 'Cuenca', 'Guayaquil']

ciudades1 = {}

for ciudad in ciudades:
    if ciudad in ciudades1:
        ciudades1[ciudad] += 1
    else:
        ciudades1[ciudad] = 1

print(ciudades1)


#Ejercicio 3 · Conjuntos en acción
# inscritos_matematica = {"Ana","Luis","Sol","Marco"} 
# y inscritos_ingles = {"Luis","Marco","Ruth"}. Responde
# con código: ¿quiénes están en las dos?, ¿quiénes solo en matemática?, ¿cuántos estudiantes 
# distintos hay en total?

inscritos_matematica = {"Ana", "Luis", "Sol", "Marco"}
inscritos_ingles = {"Luis", "Marco", "Ruth"}

ambas_materias = inscritos_matematica & inscritos_ingles
print('se inscribieron en matematica y ingles',ambas_materias )

solo_matematica = inscritos_matematica - inscritos_ingles
print('solo se inscribieron en matematicas ',solo_matematica)

todos = inscritos_matematica | inscritos_ingles
print(len(todos))


#Ejercicio 4 · De lista de diccionarios a índice
# Con clientes = [{"id":1,"nombre":"Ana"},{"id":2,"nombre":"Luis"}],
# crea un diccionario {id: cliente} para acceder por id sin recorrer la lista.
# Luego imprime el nombre del id 2.

clientes = [
    {"id": 1, "nombre": "Ana"},
    {"id": 2, "nombre": "Luis"}
]

indice = {}

for cliente in clientes:
    indice[cliente["id"]] = cliente

print(indice)
print(indice[2]["nombre"])

#Ejercicio 5 · Tuplas como registros inmutables
# Dada ventas = [("enero", 1500), ("febrero", 1800), ("marzo", 1200)], 
# imprime el mes con mayor venta y el total, usando desempaquetado de tuplas.


ventas = [("enero", 1500), ("febrero", 1800), ("marzo", 1200)]
mayor = ventas[0]
for mes, venta in ventas:
    if venta > mayor[1]:
        mayor = (mes, venta)

print("Mes con mayor venta:", mayor[0])
print("Venta:", mayor[1])


#Ejercicio6

def clientes_por_ciudad():
    agrupados = {}
    for registro in gestor.leer():
        ciudad = registro.get("ciudad", "").title() or "Sin ciudad"
        # setdefault: si la ciudad no estaba, crea la lista vacía y luego agrega
        agrupados.setdefault(ciudad, []).append(registro["nombre"])
    return agrupados